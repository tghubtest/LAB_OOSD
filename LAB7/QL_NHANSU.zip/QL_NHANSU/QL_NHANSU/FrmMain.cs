﻿using System;
using System.Windows.Forms;

namespace QL_NHANSU
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void btnTuyenDung_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chức năng Tuyển dụng & Hợp đồng lao động đang phát triển!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnChamCong_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chức năng Chấm công & Phụ trội đang phát triển!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnKhenThuong_Click(object sender, EventArgs e)
        {
            // Mở form Khen thưởng - Kỷ luật (Form chính dùng làm test case)
            FrmKhenThuong frm = new FrmKhenThuong();
            frm.ShowDialog();
        }

        private void btnLuong_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chức năng Tính lương hằng tháng đang phát triển!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnBaoCao_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chức năng Thống kê & Báo cáo đang phát triển!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muốn thoát hệ thống không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}