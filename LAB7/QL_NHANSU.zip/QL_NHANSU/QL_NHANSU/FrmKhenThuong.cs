﻿using System;
using System.Windows.Forms;

namespace QL_NHANSU
{
    public partial class FrmKhenThuong : Form
    {
        private KhenThuongService service = new KhenThuongService();

        public FrmKhenThuong()
        {
            InitializeComponent();
        }

        private void FrmKhenThuong_Load(object sender, EventArgs e)
        {
            // Tải danh sách nhân viên nếu cần
        }

        private void btnLapQuyetDinh_Click(object sender, EventArgs e)
        {
            // Lấy dữ liệu từ các điều khiển trên Form
            string maQD = txtMaQD.Text.Trim();

            // Dùng cboNhanVien cho khớp với tên trong file Designer.cs
            string maNV = cboNhanVien.Text.Trim();

            string lyDo = txtLyDo.Text.Trim();

            // Đổi tên biến thành sSoTien để tránh trùng lặp với tên điều khiển txtSoTien
            string sSoTien = txtSoTien.Text.Trim();

            // Gọi Service xử lý nghiệp vụ (Tuân thủ mô hình 3 lớp)
            string ketQua = service.XuLyLapKhenThuong(maQD, maNV, lyDo, sSoTien);

            if (ketQua == "SUCCESS")
            {
                MessageBox.Show("Lập quyết định khen thưởng và tự động sinh phiếu chi thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show(ketQua, "Cảnh báo nghiệp vụ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}