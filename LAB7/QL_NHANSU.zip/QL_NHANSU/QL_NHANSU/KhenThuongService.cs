﻿using System;
using System.Data.SqlClient;

namespace QL_NHANSU
{
    // Lớp Service (Điều khiển nghiệp vụ)
    public class KhenThuongService
    {
        private QDKhenThuongDAL dal = new QDKhenThuongDAL();

        public string XuLyLapKhenThuong(string maQD, string maNV, string lyDo, string txtSoTien)
        {
            if (string.IsNullOrEmpty(maQD) || string.IsNullOrEmpty(maNV) || string.IsNullOrEmpty(txtSoTien))
            {
                return "Vui lòng nhập đầy đủ thông tin bắt buộc!";
            }

            if (!decimal.TryParse(txtSoTien, out decimal soTien) || soTien <= 0)
            {
                return "Số tiền khen thưởng phải là số lớn hơn 0!";
            }

            bool kq = dal.LapQuyetDinhVaChiTien(maQD, maNV, lyDo, soTien);
            if (kq)
            {
                return "SUCCESS";
            }
            else
            {
                return "Lỗi hệ thống: Không thể lưu quyết định và sinh phiếu chi!";
            }
        }
    }

    // Lớp DAL (Thao tác cơ sở dữ liệu)
    public class QDKhenThuongDAL
    {
        private string connectionString = "Data Source=.;Initial Catalog=QL_NhanSuDongA;Integrated Security=True";

        public bool LapQuyetDinhVaChiTien(string maQD, string maNV, string lyDo, decimal soTien)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlTransaction transaction = conn.BeginTransaction();

                try
                {
                    // 1. Thêm quyết định khen thưởng
                    string queryQD = "INSERT INTO QDKhenThuong_KyLuat (MaQD, MaNV, LoaiQD, LyDo, SoTien, TrangThai) VALUES (@MaQD, @MaNV, N'Khen thưởng', @LyDo, @SoTien, N'Đã duyệt')";
                    using (SqlCommand cmd1 = new SqlCommand(queryQD, conn, transaction))
                    {
                        cmd1.Parameters.AddWithValue("@MaQD", maQD);
                        cmd1.Parameters.AddWithValue("@MaNV", maNV);
                        cmd1.Parameters.AddWithValue("@LyDo", lyDo);
                        cmd1.Parameters.AddWithValue("@SoTien", soTien);
                        cmd1.ExecuteNonQuery();
                    }

                    // 2. Tự động sinh Phiếu Chi tương ứng (BR10)
                    string soPhieuChi = "PC_" + maQD;
                    string queryPC = "INSERT INTO PhieuThu_Chi (SoPhieu, MaQD, LoaiPhieu, NgayLap, SoTien) VALUES (@SoPhieu, @MaQD, N'Phiếu chi', GETDATE(), @SoTien)";
                    using (SqlCommand cmd2 = new SqlCommand(queryPC, conn, transaction))
                    {
                        cmd2.Parameters.AddWithValue("@SoPhieu", soPhieuChi);
                        cmd2.Parameters.AddWithValue("@MaQD", maQD);
                        cmd2.Parameters.AddWithValue("@SoTien", soTien);
                        cmd2.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    return true;
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    return false;
                }
            }
        }
    }
}