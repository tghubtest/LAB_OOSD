﻿namespace QL_NHANSU
{
    partial class FrmKhenThuong
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.lblMaQD = new System.Windows.Forms.Label();
            this.txtMaQD = new System.Windows.Forms.TextBox();
            this.lblMaNV = new System.Windows.Forms.Label();
            this.cboNhanVien = new System.Windows.Forms.ComboBox();
            this.lblLyDo = new System.Windows.Forms.Label();
            this.txtLyDo = new System.Windows.Forms.TextBox();
            this.lblSoTien = new System.Windows.Forms.Label();
            this.txtSoTien = new System.Windows.Forms.TextBox();
            this.btnLapQuyetDinh = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.AutoSize = true;
            this.lblTieuDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDe.ForeColor = System.Drawing.Color.Navy;
            this.lblTieuDe.Location = new System.Drawing.Point(160, 25);
            this.lblTieuDe.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(644, 44);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "LẬP QUYẾT ĐỊNH KHEN THƯỞNG";
            // 
            // lblMaQD
            // 
            this.lblMaQD.AutoSize = true;
            this.lblMaQD.Location = new System.Drawing.Point(53, 100);
            this.lblMaQD.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMaQD.Name = "lblMaQD";
            this.lblMaQD.Size = new System.Drawing.Size(161, 25);
            this.lblMaQD.TabIndex = 1;
            this.lblMaQD.Text = "Mã Quyết Định:";
            // 
            // txtMaQD
            // 
            this.txtMaQD.Location = new System.Drawing.Point(240, 96);
            this.txtMaQD.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMaQD.Name = "txtMaQD";
            this.txtMaQD.Size = new System.Drawing.Size(399, 31);
            this.txtMaQD.TabIndex = 2;
            // 
            // lblMaNV
            // 
            this.lblMaNV.AutoSize = true;
            this.lblMaNV.Location = new System.Drawing.Point(53, 162);
            this.lblMaNV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMaNV.Name = "lblMaNV";
            this.lblMaNV.Size = new System.Drawing.Size(154, 25);
            this.lblMaNV.TabIndex = 3;
            this.lblMaNV.Text = "Mã Nhân Viên:";
            // 
            // cboNhanVien
            // 
            this.cboNhanVien.FormattingEnabled = true;
            this.cboNhanVien.Location = new System.Drawing.Point(240, 159);
            this.cboNhanVien.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cboNhanVien.Name = "cboNhanVien";
            this.cboNhanVien.Size = new System.Drawing.Size(399, 33);
            this.cboNhanVien.TabIndex = 4;
            // 
            // lblLyDo
            // 
            this.lblLyDo.AutoSize = true;
            this.lblLyDo.Location = new System.Drawing.Point(53, 225);
            this.lblLyDo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLyDo.Name = "lblLyDo";
            this.lblLyDo.Size = new System.Drawing.Size(74, 25);
            this.lblLyDo.TabIndex = 5;
            this.lblLyDo.Text = "Lý Do:";
            // 
            // txtLyDo
            // 
            this.txtLyDo.Location = new System.Drawing.Point(240, 221);
            this.txtLyDo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtLyDo.Multiline = true;
            this.txtLyDo.Name = "txtLyDo";
            this.txtLyDo.Size = new System.Drawing.Size(399, 74);
            this.txtLyDo.TabIndex = 6;
            // 
            // lblSoTien
            // 
            this.lblSoTien.AutoSize = true;
            this.lblSoTien.Location = new System.Drawing.Point(53, 325);
            this.lblSoTien.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSoTien.Name = "lblSoTien";
            this.lblSoTien.Size = new System.Drawing.Size(92, 25);
            this.lblSoTien.TabIndex = 7;
            this.lblSoTien.Text = "Số Tiền:";
            // 
            // txtSoTien
            // 
            this.txtSoTien.Location = new System.Drawing.Point(240, 321);
            this.txtSoTien.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSoTien.Name = "txtSoTien";
            this.txtSoTien.Size = new System.Drawing.Size(399, 31);
            this.txtSoTien.TabIndex = 8;
            // 
            // btnLapQuyetDinh
            // 
            this.btnLapQuyetDinh.BackColor = System.Drawing.Color.ForestGreen;
            this.btnLapQuyetDinh.ForeColor = System.Drawing.Color.White;
            this.btnLapQuyetDinh.Location = new System.Drawing.Point(240, 388);
            this.btnLapQuyetDinh.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLapQuyetDinh.Name = "btnLapQuyetDinh";
            this.btnLapQuyetDinh.Size = new System.Drawing.Size(187, 56);
            this.btnLapQuyetDinh.TabIndex = 9;
            this.btnLapQuyetDinh.Text = "Lập Quyết Định";
            this.btnLapQuyetDinh.UseVisualStyleBackColor = false;
            this.btnLapQuyetDinh.Click += new System.EventHandler(this.btnLapQuyetDinh_Click);
            // 
            // btnDong
            // 
            this.btnDong.Location = new System.Drawing.Point(453, 388);
            this.btnDong.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(187, 56);
            this.btnDong.TabIndex = 10;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmKhenThuong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(861, 488);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnLapQuyetDinh);
            this.Controls.Add(this.txtSoTien);
            this.Controls.Add(this.lblSoTien);
            this.Controls.Add(this.txtLyDo);
            this.Controls.Add(this.lblLyDo);
            this.Controls.Add(this.cboNhanVien);
            this.Controls.Add(this.lblMaNV);
            this.Controls.Add(this.txtMaQD);
            this.Controls.Add(this.lblMaQD);
            this.Controls.Add(this.lblTieuDe);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FrmKhenThuong";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Khen Thưởng";
            this.Load += new System.EventHandler(this.FrmKhenThuong_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.Label lblMaQD;
        private System.Windows.Forms.TextBox txtMaQD;
        private System.Windows.Forms.Label lblMaNV;
        private System.Windows.Forms.ComboBox cboNhanVien;
        private System.Windows.Forms.Label lblLyDo;
        private System.Windows.Forms.TextBox txtLyDo;
        private System.Windows.Forms.Label lblSoTien;
        private System.Windows.Forms.TextBox txtSoTien;
        private System.Windows.Forms.Button btnLapQuyetDinh;
        private System.Windows.Forms.Button btnDong;
    }
}