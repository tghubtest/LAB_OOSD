﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace eSHOPPING_Lab4
{
    public class FrmTimKiem : Form
    {
        private TextBox txtTuKhoa;
        private DataGridView dgvSanPham;
        private SanPhamServiceAdapter spAdapter = new SanPhamServiceAdapter();

        public FrmTimKiem()
        {
            this.Text = "TÌM KIẾM SẢN PHẨM";
            this.Size = new Size(500, 400);
            this.StartPosition = FormStartPosition.CenterScreen;

            // UI Elements
            Label lblTuKhoa = new Label { Text = "Nhập từ khóa:", Location = new Point(20, 25), AutoSize = true };
            txtTuKhoa = new TextBox { Location = new Point(110, 20), Width = 200 };
            Button btnTim = new Button { Text = "Tìm kiếm", Location = new Point(330, 18), Width = 100 };
            dgvSanPham = new DataGridView { Location = new Point(20, 60), Size = new Size(440, 280), ReadOnly = true };

            // Sự kiện Load và Click
            this.Load += (s, e) => { dgvSanPham.DataSource = spAdapter.LayDanhSachSanPham(""); };
            btnTim.Click += (s, e) => { dgvSanPham.DataSource = spAdapter.LayDanhSachSanPham(txtTuKhoa.Text.Trim()); };

            // Thêm vào Form
            this.Controls.Add(lblTuKhoa);
            this.Controls.Add(txtTuKhoa);
            this.Controls.Add(btnTim);
            this.Controls.Add(dgvSanPham);
        }
    }
}