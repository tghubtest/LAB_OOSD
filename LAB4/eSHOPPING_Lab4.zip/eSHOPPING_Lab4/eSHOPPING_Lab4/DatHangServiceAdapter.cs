﻿using System;
using System.Data.SqlClient;

namespace eSHOPPING_Lab4
{
    public class DatHangServiceAdapter
    {
        public bool XuLyDatHang(int maKH, string tenNhan, string diaChi, string sdt, string hinhThuc, decimal tienHang, string soThe, out string message)
        {
            // 1. Logic tính phí giao hàng bám sát BR01 - BR04 của thầy
            decimal phiGiaoHang = 0;

            if (hinhThuc == "THUONG")
            {
                phiGiaoHang = 15000;
            }
            else if (hinhThuc == "NHANH")
            {
                phiGiaoHang = (tienHang >= 1000000) ? 0 : 30000;
            }
            else if (hinhThuc == "TRONG_NGAY")
            {
                phiGiaoHang = (tienHang >= 5000000) ? 0 : 100000;
            }

            decimal tongTien = tienHang + phiGiaoHang;

            try
            {
                // =======================================================
                // (NẾU CÓ CODE LƯU SQL, BẠN ĐỂ Ở KHU VỰC NÀY)
                // =======================================================

                // 2. Chỉnh lại câu thông báo để phục vụ truy vết Test Case
                message = $"ĐẶT HÀNG THÀNH CÔNG!\n\n" +
                          $"- Hình thức giao: {hinhThuc}\n" +
                          $"- Phí giao hàng: {phiGiaoHang:N0} VNĐ\n" +
                          $"- Tổng thanh toán: {tongTien:N0} VNĐ\n\n" +
                          $"Đơn hàng đã được xử lý thành công.";
                return true;
            }
            catch (Exception ex)
            {
                message = "Lỗi thanh toán hoặc lưu dữ liệu: " + ex.Message;
                return false;
            }
        }
    }
}