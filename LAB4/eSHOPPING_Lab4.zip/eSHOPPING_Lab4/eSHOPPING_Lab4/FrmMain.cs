﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace eSHOPPING_Lab4
{
    public class FrmMain : Form
    {
        public FrmMain()
        {
            // 1. Tùy chỉnh Form nền
            this.Text = "HỆ THỐNG MUA SẮM E-SHOPPING";
            this.Size = new Size(520, 380); // Tăng chút kích thước cho thoáng
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.WhiteSmoke; // Đổi màu nền sang xám sáng cực nhẹ
            this.Font = new Font("Segoe UI", 10); // Đổi font chuẩn hiện đại

            // 2. Tùy chỉnh Tiêu đề
            Label lblTitle = new Label
            {
                Text = "QUẢN LÝ THƯƠNG MẠI ĐIỆN TỬ",
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 51, 102), // Màu xanh Navy đậm sang trọng
                Location = new Point(80, 25),
                AutoSize = true
            };
            this.Controls.Add(lblTitle);

            // 3. Hàm hỗ trợ định dạng nút bấm hàng loạt (giúp code siêu gọn)
            void StyleButton(Button btn, Point loc, Color bg, Color fg)
            {
                btn.Location = loc;
                btn.Size = new Size(200, 55); // Nút to và dài hơn một chút
                btn.FlatStyle = FlatStyle.Flat; // Xóa viền 3D cổ điển
                btn.FlatAppearance.BorderSize = 1;
                btn.FlatAppearance.BorderColor = Color.LightGray; // Viền mỏng tinh tế
                btn.BackColor = bg;
                btn.ForeColor = fg;
                btn.Font = new Font("Segoe UI", 10, FontStyle.Bold);
                btn.Cursor = Cursors.Hand; // Đưa chuột vào hiện hình bàn tay
                this.Controls.Add(btn);
            }

            // 4. Khởi tạo các nút
            Button btnTimKiem = new Button { Text = "Tìm kiếm Sản phẩm" };
            Button btnGioHang = new Button { Text = "Giỏ hàng của tôi" };
            Button btnLichSu = new Button { Text = "Lịch sử Đơn hàng" };
            Button btnTaiKhoan = new Button { Text = "Quản lý Tài khoản" };
            Button btnDatHang = new Button { Text = "Đặt hàng - Thanh toán" };
            Button btnThoat = new Button { Text = "Thoát hệ thống" };

            // 5. Áp dụng Style và Vị trí (Phối màu trắng, xanh ngọc và đỏ san hô)
            Color whiteBg = Color.White;
            Color darkText = Color.FromArgb(64, 64, 64);

            StyleButton(btnTimKiem, new Point(40, 90), whiteBg, darkText);
            StyleButton(btnGioHang, new Point(40, 160), whiteBg, darkText);
            StyleButton(btnLichSu, new Point(40, 230), whiteBg, darkText);

            StyleButton(btnTaiKhoan, new Point(260, 90), whiteBg, darkText);
            StyleButton(btnDatHang, new Point(260, 160), Color.MediumSeaGreen, Color.White); // Xanh lá hiện đại
            StyleButton(btnThoat, new Point(260, 230), Color.IndianRed, Color.White); // Đỏ nhạt 

            // 6. Gắn sự kiện
            btnTimKiem.Click += (s, e) => { new FrmTimKiem().ShowDialog(); };
            btnDatHang.Click += (s, e) => { new FrmDatHang().ShowDialog(); };
            btnThoat.Click += (s, e) => { Application.Exit(); };

            btnGioHang.Click += (s, e) => { MessageBox.Show("Chức năng đang phát triển!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information); };
            btnLichSu.Click += (s, e) => { MessageBox.Show("Chức năng đang phát triển!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information); };
            btnTaiKhoan.Click += (s, e) => { MessageBox.Show("Chức năng đang phát triển!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information); };
        }
    }
}