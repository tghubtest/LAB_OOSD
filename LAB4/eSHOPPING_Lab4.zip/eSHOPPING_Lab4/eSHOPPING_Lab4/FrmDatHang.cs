﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace eSHOPPING_Lab4
{
    public class FrmDatHang : Form
    {
        private TextBox txtHoTen, txtDiaChi, txtDienThoai, txtTienHang, txtSoThe;
        private ComboBox cbHinhThucGiao;
        private DatHangServiceAdapter dhAdapter = new DatHangServiceAdapter();

        public FrmDatHang()
        {
            this.Text = "THANH TOÁN ĐẶT HÀNG";
            this.Size = new Size(400, 420);
            this.StartPosition = FormStartPosition.CenterScreen;

            int leftLabel = 30, leftInput = 150, top = 20, step = 40;

            // Hàm hỗ trợ tạo dòng nhập liệu nhanh
            void AddRow(string labelText, Control inputControl)
            {
                this.Controls.Add(new Label { Text = labelText, Location = new Point(leftLabel, top), AutoSize = true });
                inputControl.Location = new Point(leftInput, top);
                inputControl.Width = 200;
                this.Controls.Add(inputControl);
                top += step;
            }

            // Khởi tạo các Control
            txtHoTen = new TextBox();
            txtDiaChi = new TextBox();
            txtDienThoai = new TextBox();
            txtTienHang = new TextBox { Text = "0" };
            txtSoThe = new TextBox();
            cbHinhThucGiao = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cbHinhThucGiao.Items.AddRange(new string[] { "THUONG", "NHANH", "TRONG_NGAY" });
            cbHinhThucGiao.SelectedIndex = 0;

            // Đưa lên Form
            AddRow("Họ tên nhận:", txtHoTen);
            AddRow("Địa chỉ:", txtDiaChi);
            AddRow("Điện thoại:", txtDienThoai);
            AddRow("Hình thức giao:", cbHinhThucGiao);
            AddRow("Tiền hàng:", txtTienHang);
            AddRow("Số thẻ tín dụng:", txtSoThe);

            // Nút thanh toán
            Button btnThanhToan = new Button { Text = "THANH TOÁN", Location = new Point(120, top + 10), Size = new Size(150, 40) };

            btnThanhToan.Click += (s, e) =>
            {
                try
                {
                    decimal tienHang = decimal.Parse(txtTienHang.Text);
                    string msg;
                    bool kq = dhAdapter.XuLyDatHang(1, txtHoTen.Text, txtDiaChi.Text, txtDienThoai.Text, cbHinhThucGiao.Text, tienHang, txtSoThe.Text, out msg);

                    MessageBox.Show(msg, kq ? "Thành công" : "Lỗi", MessageBoxButtons.OK, kq ? MessageBoxIcon.Information : MessageBoxIcon.Error);
                    if (kq) this.Close();
                }
                catch { MessageBox.Show("Vui lòng nhập đúng số liệu!"); }
            };

            this.Controls.Add(btnThanhToan);
        }
    }
}