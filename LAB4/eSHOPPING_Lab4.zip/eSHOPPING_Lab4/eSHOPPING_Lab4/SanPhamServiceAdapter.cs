﻿using System.Data;

namespace eSHOPPING_Lab4
{
    public class SanPhamServiceAdapter
    {
        // Giả lập gọi API Hệ thống quản lý sản phẩm bên ngoài
        public DataTable LayDanhSachSanPham(string tuKhoa)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("MaSP");
            dt.Columns.Add("TenSanPham");
            dt.Columns.Add("DonGia", typeof(decimal));
            dt.Columns.Add("SoLuongTon", typeof(int));

            // Thêm dữ liệu giả lập
            dt.Rows.Add("SP01", "Laptop Dell XPS 15", 35000000, 10);
            dt.Rows.Add("SP02", "Điện thoại iPhone 15 Pro", 28000000, 25);
            dt.Rows.Add("SP03", "Bàn phím cơ Logitech", 2500000, 50);

            // Lọc theo từ khóa nếu có
            if (!string.IsNullOrEmpty(tuKhoa))
            {
                DataView dv = dt.DefaultView;
                dv.RowFilter = $"TenSanPham LIKE '%{tuKhoa}%'";
                return dv.ToTable();
            }
            return dt;
        }
    }
}