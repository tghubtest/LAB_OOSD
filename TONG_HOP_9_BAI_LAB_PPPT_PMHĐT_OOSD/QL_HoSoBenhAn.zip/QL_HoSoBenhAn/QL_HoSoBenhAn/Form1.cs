﻿namespace QL_HoSoBenhAn
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Lấy dữ liệu người dùng vừa nhập trên giao diện
            string ten = txtHoTen.Text;
            string diachi = txtDiaChi.Text;

            if (string.IsNullOrEmpty(ten))
            {
                MessageBox.Show("Vui lòng nhập tên bệnh nhân!");
                return;
            }

            // Ở đây sẽ gọi lệnh SQL để lưu vào Database...
            MessageBox.Show("Đã lưu thông tin của: " + ten);     
         }
    }
}
