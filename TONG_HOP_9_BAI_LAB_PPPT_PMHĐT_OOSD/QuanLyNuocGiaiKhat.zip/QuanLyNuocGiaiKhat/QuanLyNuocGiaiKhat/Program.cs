﻿using System;
using System.Windows.Forms;
using QuanLyNuocGiaiKhat.Forms; 

namespace QuanLyNuocGiaiKhat
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Khởi chạy FrmMain
            Application.Run(new FrmMain());
        }
    }
}