﻿namespace QuanLyNuocGiaiKhat.Forms
{
    partial class FrmMain
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.btnDanhMuc = new System.Windows.Forms.Button();
            this.btnDonHang = new System.Windows.Forms.Button();
            this.btnPhieuGiao = new System.Windows.Forms.Button();
            this.btnBanHang = new System.Windows.Forms.Button();
            this.btnPhieuHen = new System.Windows.Forms.Button();
            this.btnPhieuNo = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblTieuDe.AutoSize = true;
            this.lblTieuDe.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTieuDe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(60)))), ((int)(((byte)(130)))));
            this.lblTieuDe.Location = new System.Drawing.Point(35, 36);
            this.lblTieuDe.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(1176, 65);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "HỆ THỐNG QUẢN LÝ CỬA HÀNG NƯỚC GIẢI KHÁT";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTieuDe.Click += new System.EventHandler(this.lblTieuDe_Click);
            // 
            // btnDanhMuc
            // 
            this.btnDanhMuc.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDanhMuc.Location = new System.Drawing.Point(60, 148);
            this.btnDanhMuc.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDanhMuc.Name = "btnDanhMuc";
            this.btnDanhMuc.Size = new System.Drawing.Size(330, 94);
            this.btnDanhMuc.TabIndex = 1;
            this.btnDanhMuc.Text = "Danh mục";
            this.btnDanhMuc.UseVisualStyleBackColor = true;
            this.btnDanhMuc.Click += new System.EventHandler(this.btnDanhMuc_Click);
            // 
            // btnDonHang
            // 
            this.btnDonHang.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDonHang.Location = new System.Drawing.Point(420, 148);
            this.btnDonHang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDonHang.Name = "btnDonHang";
            this.btnDonHang.Size = new System.Drawing.Size(330, 94);
            this.btnDonHang.TabIndex = 2;
            this.btnDonHang.Text = "Đơn đặt hàng";
            this.btnDonHang.UseVisualStyleBackColor = true;
            this.btnDonHang.Click += new System.EventHandler(this.btnDonHang_Click);
            // 
            // btnPhieuGiao
            // 
            this.btnPhieuGiao.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPhieuGiao.Location = new System.Drawing.Point(780, 148);
            this.btnPhieuGiao.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPhieuGiao.Name = "btnPhieuGiao";
            this.btnPhieuGiao.Size = new System.Drawing.Size(330, 94);
            this.btnPhieuGiao.TabIndex = 3;
            this.btnPhieuGiao.Text = "Phiếu giao hàng";
            this.btnPhieuGiao.UseVisualStyleBackColor = true;
            this.btnPhieuGiao.Click += new System.EventHandler(this.btnPhieuGiao_Click);
            // 
            // btnBanHang
            // 
            this.btnBanHang.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBanHang.Location = new System.Drawing.Point(60, 273);
            this.btnBanHang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnBanHang.Name = "btnBanHang";
            this.btnBanHang.Size = new System.Drawing.Size(330, 94);
            this.btnBanHang.TabIndex = 4;
            this.btnBanHang.Text = "Bán hàng - Thanh toán";
            this.btnBanHang.UseVisualStyleBackColor = true;
            this.btnBanHang.Click += new System.EventHandler(this.btnBanHang_Click);
            // 
            // btnPhieuHen
            // 
            this.btnPhieuHen.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPhieuHen.Location = new System.Drawing.Point(420, 273);
            this.btnPhieuHen.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPhieuHen.Name = "btnPhieuHen";
            this.btnPhieuHen.Size = new System.Drawing.Size(330, 94);
            this.btnPhieuHen.TabIndex = 5;
            this.btnPhieuHen.Text = "Giao hàng phiếu hẹn";
            this.btnPhieuHen.UseVisualStyleBackColor = true;
            this.btnPhieuHen.Click += new System.EventHandler(this.btnPhieuHen_Click);
            // 
            // btnPhieuNo
            // 
            this.btnPhieuNo.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPhieuNo.Location = new System.Drawing.Point(780, 273);
            this.btnPhieuNo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPhieuNo.Name = "btnPhieuNo";
            this.btnPhieuNo.Size = new System.Drawing.Size(330, 94);
            this.btnPhieuNo.TabIndex = 6;
            this.btnPhieuNo.Text = "Phiếu ghi nợ";
            this.btnPhieuNo.UseVisualStyleBackColor = true;
            this.btnPhieuNo.Click += new System.EventHandler(this.btnPhieuNo_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Segoe UI", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.Location = new System.Drawing.Point(420, 398);
            this.btnThoat.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(330, 94);
            this.btnThoat.TabIndex = 7;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.ClientSize = new System.Drawing.Size(1251, 522);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnPhieuNo);
            this.Controls.Add(this.btnPhieuHen);
            this.Controls.Add(this.btnBanHang);
            this.Controls.Add(this.btnPhieuGiao);
            this.Controls.Add(this.btnDonHang);
            this.Controls.Add(this.btnDanhMuc);
            this.Controls.Add(this.lblTieuDe);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý cửa hàng nước giải khát";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.Button btnDanhMuc;
        private System.Windows.Forms.Button btnDonHang;
        private System.Windows.Forms.Button btnPhieuGiao;
        private System.Windows.Forms.Button btnBanHang;
        private System.Windows.Forms.Button btnPhieuHen;
        private System.Windows.Forms.Button btnPhieuNo;
        private System.Windows.Forms.Button btnThoat;
    }
}