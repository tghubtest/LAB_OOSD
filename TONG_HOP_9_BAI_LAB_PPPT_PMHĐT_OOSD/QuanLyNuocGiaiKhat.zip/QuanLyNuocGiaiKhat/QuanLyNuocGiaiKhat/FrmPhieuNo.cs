﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyNuocGiaiKhat.Data;
using QuanLyNuocGiaiKhat.Services;

namespace QuanLyNuocGiaiKhat.Forms
{
    public partial class FrmPhieuNo : Form
    {
        private readonly PhieuNoService service = new PhieuNoService();

        public FrmPhieuNo()
        {
            InitializeComponent();
        }

        private void FrmPhieuNo_Load(object sender, EventArgs e)
        {
            txtMaPN.Text = "PN" + DateTime.Now.ToString("yyyyMMddHHmmss");
            dtpNgayTra.Value = DateTime.Now.AddDays(7);
            TaiDanhSachHoaDon();
            TaiDanhSachPhieuNo();
        }

        private void TaiDanhSachHoaDon()
        {
            cboHoaDon.DataSource = service.LayDanhSachHoaDonKhachQuen();
            cboHoaDon.DisplayMember = "SoHoaDon";
            cboHoaDon.ValueMember = "SoHoaDon";
        }

        private void TaiDanhSachPhieuNo()
        {
            dgvPhieuNo.DataSource = Db.Query(@"SELECT p.MaPhieuNo, p.SoHoaDon, k.HoTen AS TenKhach, p.SoTienNo, p.NgayDuKienTra, p.LyDoNo 
                                               FROM PhieuGhiNo p 
                                               JOIN KhachHang k ON p.MaKH = k.MaKH");
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            string maPN = txtMaPN.Text.Trim();
            string soHD = cboHoaDon.SelectedValue != null ? cboHoaDon.SelectedValue.ToString() : "";
            decimal soTienNo = numSoTienNo.Value;
            DateTime ngayTra = dtpNgayTra.Value;
            string lyDo = txtLyDo.Text.Trim();
            string maNV = "NV001"; // Mã nhân viên thao tác mặc định

            KetQuaXuLy kq = service.LapPhieuGhiNo(maPN, soHD, soTienNo, ngayTra, lyDo, maNV);

            MessageBox.Show(kq.ThongBao, "Thông báo", MessageBoxButtons.OK, kq.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (kq.ThanhCong)
            {
                txtMaPN.Text = "PN" + DateTime.Now.ToString("yyyyMMddHHmmss");
                TaiDanhSachHoaDon();
                TaiDanhSachPhieuNo();
            }
        }
    }
}