﻿namespace QuanLyNuocGiaiKhat.Forms
{
    partial class FrmBanHang
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblSoHD = new System.Windows.Forms.Label();
            this.txtSoHD = new System.Windows.Forms.TextBox();
            this.lblLoaiKhach = new System.Windows.Forms.Label();
            this.cboLoaiKhach = new System.Windows.Forms.ComboBox();
            this.lblKhachHang = new System.Windows.Forms.Label();
            this.cboKhachHang = new System.Windows.Forms.ComboBox();
            this.lblNhanVien = new System.Windows.Forms.Label();
            this.cboNhanVien = new System.Windows.Forms.ComboBox();
            this.lblNgayHen = new System.Windows.Forms.Label();
            this.dtpNgayHen = new System.Windows.Forms.DateTimePicker();

            this.lblNGK = new System.Windows.Forms.Label();
            this.cboNGK = new System.Windows.Forms.ComboBox();
            this.lblSoLuong = new System.Windows.Forms.Label();
            this.numSoLuong = new System.Windows.Forms.NumericUpDown();
            this.lblDonGia = new System.Windows.Forms.Label();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            this.btnThemMon = new System.Windows.Forms.Button();

            this.dgvGioHang = new System.Windows.Forms.DataGridView();
            this.colMaNGK = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTenNGK = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colThanhTien = new System.Windows.Forms.DataGridViewTextBoxColumn();

            this.lblTongTien = new System.Windows.Forms.Label();
            this.txtTongTien = new System.Windows.Forms.TextBox();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();

            this.panelHeader = new System.Windows.Forms.Panel();
            this.panelFooter = new System.Windows.Forms.Panel();

            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGioHang)).BeginInit();
            this.panelHeader.SuspendLayout();
            this.panelFooter.SuspendLayout();
            this.SuspendLayout();

            // panelHeader
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Height = 110;
            this.panelHeader.Controls.Add(this.lblSoHD); this.panelHeader.Controls.Add(this.txtSoHD);
            this.panelHeader.Controls.Add(this.lblLoaiKhach); this.panelHeader.Controls.Add(this.cboLoaiKhach);
            this.panelHeader.Controls.Add(this.lblKhachHang); this.panelHeader.Controls.Add(this.cboKhachHang);
            this.panelHeader.Controls.Add(this.lblNhanVien); this.panelHeader.Controls.Add(this.cboNhanVien);
            this.panelHeader.Controls.Add(this.lblNgayHen); this.panelHeader.Controls.Add(this.dtpNgayHen);
            this.panelHeader.Controls.Add(this.lblNGK); this.panelHeader.Controls.Add(this.cboNGK);
            this.panelHeader.Controls.Add(this.lblSoLuong); this.panelHeader.Controls.Add(this.numSoLuong);
            this.panelHeader.Controls.Add(this.lblDonGia); this.panelHeader.Controls.Add(this.txtDonGia);
            this.panelHeader.Controls.Add(this.btnThemMon);

            this.lblSoHD.Text = "Số HĐ:"; this.lblSoHD.Location = new System.Drawing.Point(12, 15); this.lblSoHD.AutoSize = true;
            this.txtSoHD.Location = new System.Drawing.Point(65, 12); this.txtSoHD.Size = new System.Drawing.Size(110, 22);

            this.lblLoaiKhach.Text = "Loại khách:"; this.lblLoaiKhach.Location = new System.Drawing.Point(190, 15); this.lblLoaiKhach.AutoSize = true;
            this.cboLoaiKhach.Location = new System.Drawing.Point(265, 12); this.cboLoaiKhach.Size = new System.Drawing.Size(120, 24);
            this.cboLoaiKhach.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiKhach.Items.AddRange(new object[] { "Khách vãng lai", "Khách quen" });
            this.cboLoaiKhach.SelectedIndexChanged += new System.EventHandler(this.cboLoaiKhach_SelectedIndexChanged);

            this.lblKhachHang.Text = "Khách quen:"; this.lblKhachHang.Location = new System.Drawing.Point(400, 15); this.lblKhachHang.AutoSize = true;
            this.cboKhachHang.Location = new System.Drawing.Point(485, 12); this.cboKhachHang.Size = new System.Drawing.Size(150, 24);
            this.cboKhachHang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            this.lblNhanVien.Text = "Nhân viên:"; this.lblNhanVien.Location = new System.Drawing.Point(650, 15); this.lblNhanVien.AutoSize = true;
            this.cboNhanVien.Location = new System.Drawing.Point(725, 12); this.cboNhanVien.Size = new System.Drawing.Size(140, 24);
            this.cboNhanVien.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            this.lblNgayHen.Text = "Ngày hẹn giao (nếu thiếu):"; this.lblNgayHen.Location = new System.Drawing.Point(12, 48); this.lblNgayHen.AutoSize = true;
            this.dtpNgayHen.Location = new System.Drawing.Point(175, 45); this.dtpNgayHen.Size = new System.Drawing.Size(140, 22);
            this.dtpNgayHen.Format = System.Windows.Forms.DateTimePickerFormat.Short;

            this.lblNGK.Text = "Sản phẩm:"; this.lblNGK.Location = new System.Drawing.Point(12, 78); this.lblNGK.AutoSize = true;
            this.cboNGK.Location = new System.Drawing.Point(85, 75); this.cboNGK.Size = new System.Drawing.Size(180, 24);
            this.cboNGK.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNGK.SelectedIndexChanged += new System.EventHandler(this.cboNGK_SelectedIndexChanged);

            this.lblSoLuong.Text = "SL Mua:"; this.lblSoLuong.Location = new System.Drawing.Point(280, 78); this.lblSoLuong.AutoSize = true;
            this.numSoLuong.Location = new System.Drawing.Point(335, 75); this.numSoLuong.Size = new System.Drawing.Size(70, 22);
            this.numSoLuong.Minimum = 1; this.numSoLuong.Value = 1;

            this.lblDonGia.Text = "Đơn giá:"; this.lblDonGia.Location = new System.Drawing.Point(420, 78); this.lblDonGia.AutoSize = true;
            this.txtDonGia.Location = new System.Drawing.Point(480, 75); this.txtDonGia.Size = new System.Drawing.Size(100, 22);

            this.btnThemMon.Text = "+ Thêm món"; this.btnThemMon.Location = new System.Drawing.Point(600, 72); this.btnThemMon.Size = new System.Drawing.Size(100, 28);
            this.btnThemMon.Click += new System.EventHandler(this.btnThemMon_Click);

            // dgvGioHang
            this.dgvGioHang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.colMaNGK, this.colTenNGK, this.colSoLuong, this.colDonGia, this.colThanhTien
            });
            this.colMaNGK.HeaderText = "Mã NGK"; this.colMaNGK.Width = 100;
            this.colTenNGK.HeaderText = "Tên Sản Phẩm"; this.colTenNGK.Width = 220;
            this.colSoLuong.HeaderText = "Số Lượng"; this.colSoLuong.Width = 100;
            this.colDonGia.HeaderText = "Đơn Giá"; this.colDonGia.Width = 120;
            this.colThanhTien.HeaderText = "Thành Tiền"; this.colThanhTien.Width = 150;
            this.dgvGioHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvGioHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;

            // panelFooter
            this.panelFooter.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelFooter.Height = 60;
            this.panelFooter.Controls.Add(this.lblTongTien);
            this.panelFooter.Controls.Add(this.txtTongTien);
            this.panelFooter.Controls.Add(this.btnThanhToan);
            this.panelFooter.Controls.Add(this.btnDong);

            this.lblTongTien.Text = "Tổng tiền thanh toán:"; this.lblTongTien.Location = new System.Drawing.Point(15, 20); this.lblTongTien.AutoSize = true;
            this.lblTongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.txtTongTien.Location = new System.Drawing.Point(160, 17); this.txtTongTien.Size = new System.Drawing.Size(160, 22);
            this.txtTongTien.ReadOnly = true; this.txtTongTien.Text = "0";

            this.btnThanhToan.Text = "Thanh toán & Lập hóa đơn"; this.btnThanhToan.Location = new System.Drawing.Point(360, 12); this.btnThanhToan.Size = new System.Drawing.Size(180, 36);
            this.btnThanhToan.BackColor = System.Drawing.Color.LightGreen;
            this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);

            this.btnDong.Text = "Đóng"; this.btnDong.Location = new System.Drawing.Point(780, 12); this.btnDong.Size = new System.Drawing.Size(80, 36);
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            // Form Main setup
            this.ClientSize = new System.Drawing.Size(884, 481);
            this.Controls.Add(this.dgvGioHang);
            this.Controls.Add(this.panelFooter);
            this.Controls.Add(this.panelHeader);
            this.Name = "FrmBanHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bán hàng và Lập Hóa đơn";
            this.Load += new System.EventHandler(this.FrmBanHang_Load);

            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGioHang)).EndInit();
            this.panelHeader.ResumeLayout(false); this.panelHeader.PerformLayout();
            this.panelFooter.ResumeLayout(false); this.panelFooter.PerformLayout();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Label lblSoHD;
        private System.Windows.Forms.TextBox txtSoHD;
        private System.Windows.Forms.Label lblLoaiKhach;
        private System.Windows.Forms.ComboBox cboLoaiKhach;
        private System.Windows.Forms.Label lblKhachHang;
        private System.Windows.Forms.ComboBox cboKhachHang;
        private System.Windows.Forms.Label lblNhanVien;
        private System.Windows.Forms.ComboBox cboNhanVien;
        private System.Windows.Forms.Label lblNgayHen;
        private System.Windows.Forms.DateTimePicker dtpNgayHen;
        private System.Windows.Forms.Label lblNGK;
        private System.Windows.Forms.ComboBox cboNGK;
        private System.Windows.Forms.Label lblSoLuong;
        private System.Windows.Forms.NumericUpDown numSoLuong;
        private System.Windows.Forms.Label lblDonGia;
        private System.Windows.Forms.TextBox txtDonGia;
        private System.Windows.Forms.Button btnThemMon;

        private System.Windows.Forms.DataGridView dgvGioHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaNGK;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTenNGK;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSoLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn colThanhTien;

        private System.Windows.Forms.Panel panelFooter;
        private System.Windows.Forms.Label lblTongTien;
        private System.Windows.Forms.TextBox txtTongTien;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.Button btnDong;
    }
}