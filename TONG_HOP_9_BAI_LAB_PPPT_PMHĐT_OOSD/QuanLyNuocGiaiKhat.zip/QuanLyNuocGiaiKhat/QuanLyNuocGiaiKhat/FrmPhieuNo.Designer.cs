﻿namespace QuanLyNuocGiaiKhat.Forms
{
    partial class FrmPhieuNo
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblMaPN = new System.Windows.Forms.Label();
            this.txtMaPN = new System.Windows.Forms.TextBox();
            this.lblSoHD = new System.Windows.Forms.Label();
            this.cboHoaDon = new System.Windows.Forms.ComboBox();
            this.lblSoTienNo = new System.Windows.Forms.Label();
            this.numSoTienNo = new System.Windows.Forms.NumericUpDown();
            this.lblNgayTra = new System.Windows.Forms.Label();
            this.dtpNgayTra = new System.Windows.Forms.DateTimePicker();
            this.lblLyDo = new System.Windows.Forms.Label();
            this.txtLyDo = new System.Windows.Forms.TextBox();
            this.btnLuu = new System.Windows.Forms.Button();
            this.dgvPhieuNo = new System.Windows.Forms.DataGridView();
            this.panelTop = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.numSoTienNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuNo)).BeginInit();
            this.panelTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblMaPN
            // 
            this.lblMaPN.AutoSize = true;
            this.lblMaPN.Location = new System.Drawing.Point(15, 15);
            this.lblMaPN.Name = "lblMaPN";
            this.lblMaPN.Size = new System.Drawing.Size(142, 25);
            this.lblMaPN.TabIndex = 0;
            this.lblMaPN.Text = "Mã Phiếu Nợ:";
            // 
            // txtMaPN
            // 
            this.txtMaPN.Location = new System.Drawing.Point(100, 12);
            this.txtMaPN.Name = "txtMaPN";
            this.txtMaPN.Size = new System.Drawing.Size(120, 31);
            this.txtMaPN.TabIndex = 1;
            // 
            // lblSoHD
            // 
            this.lblSoHD.AutoSize = true;
            this.lblSoHD.Location = new System.Drawing.Point(240, 15);
            this.lblSoHD.Name = "lblSoHD";
            this.lblSoHD.Size = new System.Drawing.Size(102, 25);
            this.lblSoHD.TabIndex = 2;
            this.lblSoHD.Text = "Hóa Đơn:";
            // 
            // cboHoaDon
            // 
            this.cboHoaDon.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboHoaDon.Location = new System.Drawing.Point(305, 12);
            this.cboHoaDon.Name = "cboHoaDon";
            this.cboHoaDon.Size = new System.Drawing.Size(220, 33);
            this.cboHoaDon.TabIndex = 3;
            // 
            // lblSoTienNo
            // 
            this.lblSoTienNo.AutoSize = true;
            this.lblSoTienNo.Location = new System.Drawing.Point(545, 15);
            this.lblSoTienNo.Name = "lblSoTienNo";
            this.lblSoTienNo.Size = new System.Drawing.Size(125, 25);
            this.lblSoTienNo.TabIndex = 4;
            this.lblSoTienNo.Text = "Số Tiền Nợ:";
            // 
            // numSoTienNo
            // 
            this.numSoTienNo.Location = new System.Drawing.Point(625, 12);
            this.numSoTienNo.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numSoTienNo.Name = "numSoTienNo";
            this.numSoTienNo.Size = new System.Drawing.Size(130, 31);
            this.numSoTienNo.TabIndex = 5;
            // 
            // lblNgayTra
            // 
            this.lblNgayTra.AutoSize = true;
            this.lblNgayTra.Location = new System.Drawing.Point(15, 52);
            this.lblNgayTra.Name = "lblNgayTra";
            this.lblNgayTra.Size = new System.Drawing.Size(188, 25);
            this.lblNgayTra.TabIndex = 6;
            this.lblNgayTra.Text = "Ngày Dự Kiến Trả:";
            // 
            // dtpNgayTra
            // 
            this.dtpNgayTra.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgayTra.Location = new System.Drawing.Point(125, 49);
            this.dtpNgayTra.Name = "dtpNgayTra";
            this.dtpNgayTra.Size = new System.Drawing.Size(130, 31);
            this.dtpNgayTra.TabIndex = 7;
            // 
            // lblLyDo
            // 
            this.lblLyDo.AutoSize = true;
            this.lblLyDo.Location = new System.Drawing.Point(270, 52);
            this.lblLyDo.Name = "lblLyDo";
            this.lblLyDo.Size = new System.Drawing.Size(107, 25);
            this.lblLyDo.TabIndex = 8;
            this.lblLyDo.Text = "Lý Do Nợ:";
            // 
            // txtLyDo
            // 
            this.txtLyDo.Location = new System.Drawing.Point(335, 49);
            this.txtLyDo.Name = "txtLyDo";
            this.txtLyDo.Size = new System.Drawing.Size(420, 31);
            this.txtLyDo.TabIndex = 9;
            // 
            // btnLuu
            // 
            this.btnLuu.Location = new System.Drawing.Point(335, 82);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(120, 30);
            this.btnLuu.TabIndex = 10;
            this.btnLuu.Text = "Lưu Phiếu Nợ";
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // dgvPhieuNo
            // 
            this.dgvPhieuNo.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPhieuNo.ColumnHeadersHeight = 46;
            this.dgvPhieuNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPhieuNo.Location = new System.Drawing.Point(0, 120);
            this.dgvPhieuNo.Name = "dgvPhieuNo";
            this.dgvPhieuNo.RowHeadersWidth = 82;
            this.dgvPhieuNo.Size = new System.Drawing.Size(811, 297);
            this.dgvPhieuNo.TabIndex = 0;
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this.lblMaPN);
            this.panelTop.Controls.Add(this.txtMaPN);
            this.panelTop.Controls.Add(this.lblSoHD);
            this.panelTop.Controls.Add(this.cboHoaDon);
            this.panelTop.Controls.Add(this.lblSoTienNo);
            this.panelTop.Controls.Add(this.numSoTienNo);
            this.panelTop.Controls.Add(this.lblNgayTra);
            this.panelTop.Controls.Add(this.dtpNgayTra);
            this.panelTop.Controls.Add(this.lblLyDo);
            this.panelTop.Controls.Add(this.txtLyDo);
            this.panelTop.Controls.Add(this.btnLuu);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(811, 120);
            this.panelTop.TabIndex = 1;
            // 
            // FrmPhieuNo
            // 
            this.ClientSize = new System.Drawing.Size(811, 417);
            this.Controls.Add(this.dgvPhieuNo);
            this.Controls.Add(this.panelTop);
            this.Name = "FrmPhieuNo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Phiếu Ghi Nợ";
            this.Load += new System.EventHandler(this.FrmPhieuNo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numSoTienNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhieuNo)).EndInit();
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Label lblMaPN;
        private System.Windows.Forms.TextBox txtMaPN;
        private System.Windows.Forms.Label lblSoHD;
        private System.Windows.Forms.ComboBox cboHoaDon;
        private System.Windows.Forms.Label lblSoTienNo;
        private System.Windows.Forms.NumericUpDown numSoTienNo;
        private System.Windows.Forms.Label lblNgayTra;
        private System.Windows.Forms.DateTimePicker dtpNgayTra;
        private System.Windows.Forms.Label lblLyDo;
        private System.Windows.Forms.TextBox txtLyDo;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.DataGridView dgvPhieuNo;
    }
}