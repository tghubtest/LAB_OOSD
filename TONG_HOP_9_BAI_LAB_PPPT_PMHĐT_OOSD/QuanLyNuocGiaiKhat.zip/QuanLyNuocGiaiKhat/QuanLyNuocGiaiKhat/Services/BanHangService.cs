﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using QuanLyNuocGiaiKhat.Data;

namespace QuanLyNuocGiaiKhat.Services
{
    public class ChiTietMuaItem
    {
        public string MaNGK { get; set; }
        public int SoLuongMua { get; set; }
        public decimal DonGia { get; set; }
    }

    public class BanHangService
    {
        public KetQuaXuLy TaoHoaDonVaPhieuHen(
            string soHD,
            string loaiKhach,
            string maKH,
            string maNV,
            List<ChiTietMuaItem> dsMua,
            DateTime? ngayHenGiao)
        {
            if (dsMua == null || dsMua.Count == 0)
                return KetQuaXuLy.Fail("Danh sách mua hàng không được rỗng.");

            if (loaiKhach == "Khách quen" && string.IsNullOrEmpty(maKH))
                return KetQuaXuLy.Fail("Khách quen phải có thông tin mã khách hàng.");

            using (SqlConnection conn = new SqlConnection(Db.ConnectionString))
            {
                conn.Open();
                SqlTransaction tran = conn.BeginTransaction();
                try
                {
                    decimal tongTien = 0;
                    bool coHangThieu = false;

                    Dictionary<string, int> soLuongGiaoThucTe = new Dictionary<string, int>();
                    Dictionary<string, int> soLuongHenGiao = new Dictionary<string, int>();

                    foreach (var item in dsMua)
                    {
                        string sqlCheck = "SELECT SoLuongTon FROM NuocGiaiKhat WITH (UPDLOCK) WHERE MaNGK = @m";
                        SqlCommand cmdCheck = new SqlCommand(sqlCheck, conn, tran);
                        cmdCheck.Parameters.AddWithValue("@m", item.MaNGK);

                        object result = cmdCheck.ExecuteScalar();
                        if (result == null)
                        {
                            tran.Rollback();
                            return KetQuaXuLy.Fail($"Mặt hàng {item.MaNGK} không tồn tại.");
                        }

                        int tonKho = Convert.ToInt32(result);

                        if (tonKho >= item.SoLuongMua)
                        {
                            soLuongGiaoThucTe[item.MaNGK] = item.SoLuongMua;
                            soLuongHenGiao[item.MaNGK] = 0;
                        }
                        else
                        {
                            if (loaiKhach == "Khách vãng lai")
                            {
                                tran.Rollback();
                                return KetQuaXuLy.Fail($"Kho không đủ mặt hàng {item.MaNGK}. Khách vãng lai vui lòng chọn số lượng <= {tonKho}.");
                            }

                            coHangThieu = true;
                            soLuongGiaoThucTe[item.MaNGK] = tonKho;
                            soLuongHenGiao[item.MaNGK] = item.SoLuongMua - tonKho;
                        }

                        tongTien += item.SoLuongMua * item.DonGia;
                    }

                    // Sửa lỗi chữ N ở đây
                    string trangThaiGiao = coHangThieu ? "Chờ giao hẹn" : "Đã giao đủ";

                    string sqlHD = @"INSERT INTO HoaDon (SoHoaDon, NgayLap, LoaiKhach, MaKH, MaNV, TongTien, TrangThaiGiao) 
                                     VALUES (@soHD, GETDATE(), @loaiKhach, @maKH, @maNV, @tongTien, @trangThaiGiao)";
                    SqlCommand cmdHD = new SqlCommand(sqlHD, conn, tran);
                    cmdHD.Parameters.AddWithValue("@soHD", soHD);
                    cmdHD.Parameters.AddWithValue("@loaiKhach", loaiKhach);
                    cmdHD.Parameters.AddWithValue("@maKH", (object)maKH ?? DBNull.Value);
                    cmdHD.Parameters.AddWithValue("@maNV", maNV);
                    cmdHD.Parameters.AddWithValue("@tongTien", tongTien);
                    cmdHD.Parameters.AddWithValue("@trangThaiGiao", trangThaiGiao);
                    cmdHD.ExecuteNonQuery();

                    foreach (var item in dsMua)
                    {
                        int slGiao = soLuongGiaoThucTe[item.MaNGK];

                        string sqlCTHD = @"INSERT INTO ChiTietHoaDon (SoHoaDon, MaNGK, SoLuong, SoLuongDaGiao, DonGia) 
                                           VALUES (@soHD, @maNGK, @slMua, @slGiao, @donGia)";
                        SqlCommand cmdCTHD = new SqlCommand(sqlCTHD, conn, tran);
                        cmdCTHD.Parameters.AddWithValue("@soHD", soHD);
                        cmdCTHD.Parameters.AddWithValue("@maNGK", item.MaNGK);
                        cmdCTHD.Parameters.AddWithValue("@slMua", item.SoLuongMua);
                        cmdCTHD.Parameters.AddWithValue("@slGiao", slGiao);
                        cmdCTHD.Parameters.AddWithValue("@donGia", item.DonGia);
                        cmdCTHD.ExecuteNonQuery();

                        if (slGiao > 0)
                        {
                            string sqlTruTon = "UPDATE NuocGiaiKhat SET SoLuongTon = SoLuongTon - @sl WHERE MaNGK = @maNGK";
                            SqlCommand cmdTruTon = new SqlCommand(sqlTruTon, conn, tran);
                            cmdTruTon.Parameters.AddWithValue("@sl", slGiao);
                            cmdTruTon.Parameters.AddWithValue("@maNGK", item.MaNGK);
                            cmdTruTon.ExecuteNonQuery();
                        }
                    }

                    if (coHangThieu && loaiKhach == "Khách quen")
                    {
                        if (!ngayHenGiao.HasValue || ngayHenGiao.Value <= DateTime.Now.Date)
                        {
                            tran.Rollback();
                            return KetQuaXuLy.Fail("Hàng trong kho thiếu. Vui lòng chọn ngày hẹn giao trong tương lai.");
                        }

                        string maPhieuHen = "PH" + DateTime.Now.ToString("yyyyMMddHHmmss");
                        // Sửa lỗi chữ N ở đây
                        string sqlPH = @"INSERT INTO PhieuHenGiao (MaPhieuHen, SoHoaDon, NgayLap, NgayHenGiao, MaNV, TrangThai) 
                                         VALUES (@maPH, @soHD, CAST(GETDATE() AS DATE), @ngayHen, @maNV, N'Chờ giao')";
                        SqlCommand cmdPH = new SqlCommand(sqlPH, conn, tran);
                        cmdPH.Parameters.AddWithValue("@maPH", maPhieuHen);
                        cmdPH.Parameters.AddWithValue("@soHD", soHD);
                        cmdPH.Parameters.AddWithValue("@ngayHen", ngayHenGiao.Value.Date);
                        cmdPH.Parameters.AddWithValue("@maNV", maNV);
                        cmdPH.ExecuteNonQuery();

                        foreach (var item in dsMua)
                        {
                            int slHen = soLuongHenGiao[item.MaNGK];
                            if (slHen > 0)
                            {
                                string sqlCTPH = @"INSERT INTO ChiTietPhieuHenGiao (MaPhieuHen, MaNGK, SoLuongHen) 
                                                   VALUES (@maPH, @maNGK, @slHen)";
                                SqlCommand cmdCTPH = new SqlCommand(sqlCTPH, conn, tran);
                                cmdCTPH.Parameters.AddWithValue("@maPH", maPhieuHen);
                                cmdCTPH.Parameters.AddWithValue("@maNGK", item.MaNGK);
                                cmdCTPH.Parameters.AddWithValue("@slHen", slHen);
                                cmdCTPH.ExecuteNonQuery();
                            }
                        }
                    }

                    tran.Commit();
                    return KetQuaXuLy.Ok(coHangThieu
                        ? "Đã bán hàng thành công! Đã giao phần có sẵn và tạo Phiếu hẹn giao cho phần còn thiếu."
                        : "Đã thanh toán và giao đủ hàng thành công.");
                }
                catch (Exception ex)
                {
                    tran.Rollback();
                    return KetQuaXuLy.Fail("Lỗi hệ thống: " + ex.Message);
                }
            }
        }
    }
}