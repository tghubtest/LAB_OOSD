﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyNuocGiaiKhat.Data;

namespace QuanLyNuocGiaiKhat.Services
{
    public class PhieuNoService
    {
        public DataTable LayDanhSachHoaDonKhachQuen()
        {
            // Đã sửa chữ N trong SQL Query string chuẩn
            return Db.Query(@"SELECT h.SoHoaDon, h.NgayLap, k.HoTen AS TenKhach, h.TongTien 
                              FROM HoaDon h 
                              JOIN KhachHang k ON h.MaKH = k.MaKH 
                              LEFT JOIN PhieuGhiNo p ON h.SoHoaDon = p.SoHoaDon 
                              WHERE h.LoaiKhach = N'Khách quen' AND p.MaPhieuNo IS NULL");
        }

        public KetQuaXuLy LapPhieuGhiNo(string maPN, string soHD, decimal soTienNo, DateTime ngayHenTra, string lyDo, string maNV)
        {
            if (string.IsNullOrWhiteSpace(maPN) || string.IsNullOrWhiteSpace(soHD))
                return KetQuaXuLy.Fail("Mã phiếu nợ và Số hóa đơn không được để trống.");

            DataTable dtHD = Db.Query("SELECT MaKH, TongTien, LoaiKhach FROM HoaDon WHERE SoHoaDon = @s", new SqlParameter("@s", soHD));
            if (dtHD.Rows.Count == 0)
                return KetQuaXuLy.Fail("Hóa đơn không tồn tại.");

            string loaiKhach = dtHD.Rows[0]["LoaiKhach"].ToString();
            if (loaiKhach != "Khách quen")
                return KetQuaXuLy.Fail("Khách vãng lai không được phép lập phiếu ghi nợ.");

            decimal tongTien = Convert.ToDecimal(dtHD.Rows[0]["TongTien"]);
            if (soTienNo <= 0 || soTienNo > tongTien)
                return KetQuaXuLy.Fail($"Số tiền nợ phải > 0 và <= Tổng tiền hóa đơn ({tongTien:N0}đ).");

            if (ngayHenTra.Date <= DateTime.Now.Date)
                return KetQuaXuLy.Fail("Ngày dự kiến trả phải sau ngày lập phiếu.");

            string maKH = dtHD.Rows[0]["MaKH"].ToString();

            try
            {
                string sql = @"INSERT INTO PhieuGhiNo (MaPhieuNo, SoHoaDon, MaKH, NgayLap, SoTienNo, NgayDuKienTra, LyDoNo, MaNV) 
                               VALUES (@maPN, @soHD, @maKH, CAST(GETDATE() AS DATE), @tien, @ngayTra, @lyDo, @maNV)";
                Db.Execute(sql,
                    new SqlParameter("@maPN", maPN),
                    new SqlParameter("@soHD", soHD),
                    new SqlParameter("@maKH", maKH),
                    new SqlParameter("@tien", soTienNo),
                    new SqlParameter("@ngayTra", ngayHenTra.Date),
                    new SqlParameter("@lyDo", (object)lyDo ?? DBNull.Value),
                    new SqlParameter("@maNV", maNV));

                return KetQuaXuLy.Ok("Lập phiếu ghi nợ thành công!");
            }
            catch (Exception ex)
            {
                return KetQuaXuLy.Fail("Lỗi khi lưu phiếu nợ: " + ex.Message);
            }
        }
    }
}