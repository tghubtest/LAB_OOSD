﻿using System;
using System.Windows.Forms;

namespace QuanLyNuocGiaiKhat.Forms
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void btnDanhMuc_Click(object sender, EventArgs e)
        {
            FrmDanhMuc frm = new FrmDanhMuc();
            frm.ShowDialog();
        }

        private void btnDonHang_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mở màn hình Đơn đặt hàng nhà cung ứng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnPhieuGiao_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mở màn hình Phiếu giao hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnBanHang_Click(object sender, EventArgs e)
        {
            FrmBanHang frm = new FrmBanHang();
            frm.ShowDialog();
        }

        private void btnPhieuHen_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mở màn hình Giao hàng theo phiếu hẹn", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnPhieuNo_Click(object sender, EventArgs e)
        {
            FrmPhieuNo frm = new FrmPhieuNo();
            frm.ShowDialog();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muốn thoát khỏi hệ thống?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void lblTieuDe_Click(object sender, EventArgs e)
        {

        }

        private void FrmMain_Load(object sender, EventArgs e)
        {

        }
    }
}