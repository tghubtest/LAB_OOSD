﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using QuanLyNuocGiaiKhat.Data;
using QuanLyNuocGiaiKhat.Services;

namespace QuanLyNuocGiaiKhat.Forms
{
    public partial class FrmBanHang : Form
    {
        private readonly BanHangService service = new BanHangService();
        private readonly List<ChiTietMuaItem> dsGioHang = new List<ChiTietMuaItem>();

        public FrmBanHang()
        {
            InitializeComponent();
        }

        private void FrmBanHang_Load(object sender, EventArgs e)
        {
            txtSoHD.Text = "HD" + DateTime.Now.ToString("yyyyMMddHHmmss");
            cboLoaiKhach.SelectedIndex = 0; // Khách vãng lai
            dtpNgayHen.Value = DateTime.Now.AddDays(1);

            LoadDataControls();
        }

        private void LoadDataControls()
        {
            // Load Nhân viên
            cboNhanVien.DataSource = Db.Query("SELECT MaNV, HoTen FROM NhanVien");
            cboNhanVien.DisplayMember = "HoTen";
            cboNhanVien.ValueMember = "MaNV";

            // Load Khách quen
            cboKhachHang.DataSource = Db.Query("SELECT MaKH, HoTen FROM KhachHang WHERE LoaiKhach = N'Khách quen'");
            cboKhachHang.DisplayMember = "HoTen";
            cboKhachHang.ValueMember = "MaKH";

            // Load Nước giải khát
            cboNGK.DataSource = Db.Query("SELECT MaNGK, TenNGK FROM NuocGiaiKhat");
            cboNGK.DisplayMember = "TenNGK";
            cboNGK.ValueMember = "MaNGK";
        }

        private void cboLoaiKhach_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool isKhachQuen = cboLoaiKhach.SelectedItem.ToString() == "Khách quen";
            cboKhachHang.Enabled = isKhachQuen;
            dtpNgayHen.Enabled = isKhachQuen;
        }

        private void cboNGK_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboNGK.SelectedValue != null)
            {
                DataTable dt = Db.Query("SELECT DonViTinh FROM NuocGiaiKhat WHERE MaNGK = @m",
                    new System.Data.SqlClient.SqlParameter("@m", cboNGK.SelectedValue.ToString()));
                if (dt.Rows.Count > 0)
                {
                    txtDonGia.Text = "15000"; // Đơn giá mẫu nhập thủ công hoặc cấu hình mặc định
                }
            }
        }

        private void btnThemMon_Click(object sender, EventArgs e)
        {
            if (cboNGK.SelectedValue == null) return;

            string ma = cboNGK.SelectedValue.ToString();
            string ten = cboNGK.Text;
            int sl = (int)numSoLuong.Value;
            decimal gia = decimal.TryParse(txtDonGia.Text, out decimal g) ? g : 0;

            var item = dsGioHang.Find(x => x.MaNGK == ma);
            if (item != null)
            {
                item.SoLuongMua += sl;
            }
            else
            {
                dsGioHang.Add(new ChiTietMuaItem { MaNGK = ma, SoLuongMua = sl, DonGia = gia });
            }

            CapNhatGioHang();
        }

        private void CapNhatGioHang()
        {
            dgvGioHang.Rows.Clear();
            decimal tongTien = 0;

            foreach (var i in dsGioHang)
            {
                DataTable dt = Db.Query("SELECT TenNGK FROM NuocGiaiKhat WHERE MaNGK = @m",
                    new System.Data.SqlClient.SqlParameter("@m", i.MaNGK));
                string tenNGK = dt.Rows.Count > 0 ? dt.Rows[0]["TenNGK"].ToString() : i.MaNGK;
                decimal thanhTien = i.SoLuongMua * i.DonGia;
                tongTien += thanhTien;

                dgvGioHang.Rows.Add(i.MaNGK, tenNGK, i.SoLuongMua, i.DonGia.ToString("N0"), thanhTien.ToString("N0"));
            }

            txtTongTien.Text = tongTien.ToString("N0");
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            string soHD = txtSoHD.Text.Trim();
            string loaiKhach = cboLoaiKhach.SelectedItem.ToString();
            string maKH = loaiKhach == "Khách quen" && cboKhachHang.SelectedValue != null
                ? cboKhachHang.SelectedValue.ToString() : null;
            string maNV = cboNhanVien.SelectedValue != null ? cboNhanVien.SelectedValue.ToString() : "";
            DateTime? ngayHen = loaiKhach == "Khách quen" ? (DateTime?)dtpNgayHen.Value : null;

            KetQuaXuLy kq = service.TaoHoaDonVaPhieuHen(soHD, loaiKhach, maKH, maNV, dsGioHang, ngayHen);

            MessageBox.Show(kq.ThongBao, "Kết quả", MessageBoxButtons.OK, kq.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (kq.ThanhCong)
            {
                dsGioHang.Clear();
                CapNhatGioHang();
                txtSoHD.Text = "HD" + DateTime.Now.ToString("yyyyMMddHHmmss");
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}